# Intro

WebExpo 2025 - May 28, 29 and 30.

## URL

https://webexpo.net/

## Content

WebExpo will be returning to Prague, for the 17th time. We're brining the brightest people from around the world for an amazing 3 days of sessions and workshops. 

May 28 and May 29 are the conference days, including 3 big rooms of sessions, back to back. We also have a baby and kids crache, mentoring sessions, disruption panels, parties, socialising and opportunties to see what our Partners are working on in the Partner Hall.

This is the place to be to see a broad range of specialists who work with the web. From designers and developers, UXers to Product, leadership and marketing. WebExpo is the place to get a broad view of what's required when building a cutting edge digital company. 

